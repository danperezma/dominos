employees = {
    'spena' : {
        'name': 'Elizabeth',
        'total': 0,
        'aditionals': 0,
    },
    'user_rs1': {
        'name': 'Cristian',
        'total': 0,
        'aditionals': 0,
    },
    'useralsea' : {
        'name': 'Natalia',
        'total': 0,
        'aditionals': 0,
    },
    'vojeda': {
        'name': 'Diego',
        'total': 0,
        'aditionals': 0,
    },
    'vsalamanca': {
        'name': 'Dayana',
        'total': 0,
        'aditionals': 0,
    },
    'wsalamanca': {
        'name': 'Wilson',
        'total': 0,
        'aditionals': 0,
    },
    'ydiaz': {
        'name': 'Tatiana',
        'total': 0,
        'aditionals': 0,
    },
    'ylara': {
        'name': 'Andrea',
        'total': 0,
        'aditionals': 0,
    },
}

costumers = {
    '12345': {
        'Nombre': 'Daniel',
        'Apellido': 'Perez',
        'Calle': '',
        'Exterior': '',
        'Codigo Postal': '',
        'Colonia': '',
    },
}