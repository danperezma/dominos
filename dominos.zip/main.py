from login import login
from number import number

def main():
    login()
    # number()
if __name__ == '__main__':
    main()